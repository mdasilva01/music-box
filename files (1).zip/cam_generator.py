"""
3D Cylindrical Cam Generator
==============================
Converts a 3D input trajectory into a printable cylindrical cam with a groove.

Based on the approach of Cheng et al. 2021 "Spatial-Temporal Motion Control via
Composite Cam-follower Mechanisms" (SIGGRAPH Asia 2021).

HOW IT WORKS:
  - The cam is a cylinder that rotates about the Z axis.
  - The follower pin rides in a groove cut into the cylinder's surface.
  - As the cam rotates one full revolution (0→2π), the groove guides the follower
    pin through the full input trajectory.
  - The trajectory's X component maps to the cam's AXIAL (Z) direction.
  - The trajectory's Y component maps to RADIAL depth (groove depth variation).
  - The trajectory's Z component is the angular parameter (rotation angle).
  - If your input is a plain 3D curve, it gets re-parameterized by arc-length
    and mapped uniformly across one full cam rotation.

INPUT CURVE FORMAT (CSV):
  Three columns: x, y, z  (one point per row, no header needed)
  Example:
    0.0, 0.0, 0.0
    1.0, 2.0, 5.0
    ...

USAGE:
  python cam_generator.py                        # uses built-in demo curve
  python cam_generator.py my_curve.csv           # use your own curve
  python cam_generator.py my_curve.csv out.stl   # specify output filename

OUTPUT:
  A binary STL file ready for 3D printing or import into CAD software.

PARAMETERS (edit below):
  CAM_RADIUS       - outer radius of the cylinder (mm)
  CAM_HEIGHT       - total height of the cylinder (mm)
  GROOVE_WIDTH     - width of the follower groove (mm)
  GROOVE_DEPTH     - how deep the groove is cut (mm)
  N_ANGULAR        - angular resolution (more = smoother, slower)
  N_PROFILE        - cross-section resolution around groove
"""

import sys
import os
import numpy as np
import struct

# ─────────────────────────────────────────────
#  USER PARAMETERS — edit these to taste
# ─────────────────────────────────────────────
CAM_RADIUS   = 30.0   # mm  — outer radius of cylinder
CAM_HEIGHT   = 40.0   # mm  — total height of cylinder
GROOVE_WIDTH =  4.0   # mm  — width of the groove channel
GROOVE_DEPTH =  5.0   # mm  — how deep the groove is cut into the surface
N_ANGULAR    = 360    # angular steps around the cam (≥180 recommended)
N_PROFILE    =  12    # cross-section points around the groove tube


# ─────────────────────────────────────────────
#  BUILT-IN DEMO CURVES
# ─────────────────────────────────────────────

def demo_figure8():
    """A figure-8 / lemniscate in 3D — a nice demo shape."""
    t = np.linspace(0, 2 * np.pi, 400, endpoint=False)
    x = 18 * np.sin(t)               # axial travel ±18 mm
    y =  8 * np.sin(2 * t)           # radial depth variation ±8 mm
    z = np.zeros_like(t)             # placeholder (will be re-param'd)
    return np.column_stack([x, y, z])


def demo_sine_wave():
    """Simple sine wave along the barrel — classic cylindrical cam shape."""
    t = np.linspace(0, 2 * np.pi, 400, endpoint=False)
    x = (CAM_HEIGHT * 0.35) * np.sin(t)   # axial oscillation
    y = np.zeros_like(t)                   # constant radius (pure axial cam)
    z = np.zeros_like(t)
    return np.column_stack([x, y, z])


def demo_helix_lobe():
    """Helical rise with a lobe bump — common in automata."""
    t = np.linspace(0, 2 * np.pi, 400, endpoint=False)
    x = 14 * t / (2 * np.pi) - 7          # linear axial rise
    x += 5 * np.sin(3 * t)                # three lobes
    y = 3 * np.sin(2 * t)                  # slight radial variation
    z = np.zeros_like(t)
    return np.column_stack([x, y, z])


def demo_star():
    """Star-shaped path projected onto cam surface."""
    t = np.linspace(0, 2 * np.pi, 400, endpoint=False)
    n_points = 5
    r = 1 + 0.5 * np.cos(n_points * t)
    x = 15 * r * np.sin(t)
    y = 6  * r * np.cos(t)
    z = np.zeros_like(t)
    return np.column_stack([x, y, z])


# ─────────────────────────────────────────────
#  CURVE PROCESSING
# ─────────────────────────────────────────────

def load_curve_csv(filepath):
    """Load a 3D curve from a CSV file (3 columns: x, y, z)."""
    pts = []
    with open(filepath) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = [p.strip() for p in line.replace(';', ',').split(',')]
            if len(parts) >= 3:
                try:
                    pts.append([float(parts[0]), float(parts[1]), float(parts[2])])
                except ValueError:
                    continue  # skip header rows
    if len(pts) < 4:
        raise ValueError(f"Need at least 4 points in CSV, found {len(pts)}")
    return np.array(pts, dtype=float)


def resample_by_arclength(pts, n):
    """Resample a curve to n uniformly-spaced points by arc length."""
    diffs = np.diff(pts, axis=0)
    seg_len = np.linalg.norm(diffs, axis=1)
    cumlen = np.concatenate([[0], np.cumsum(seg_len)])
    total = cumlen[-1]
    target = np.linspace(0, total, n)
    resampled = np.zeros((n, pts.shape[1]))
    for i in range(pts.shape[1]):
        resampled[:, i] = np.interp(target, cumlen, pts[:, i])
    return resampled


def normalize_to_cam(curve, cam_radius, cam_height, groove_depth):
    """
    Map the input 3D curve onto cam surface parameters.

    Returns arrays:
      theta   - rotation angle [0, 2π)  for each sample
      z_pos   - axial position along the cam cylinder
      r_pos   - radial position (cam_radius - groove_depth to cam_radius)

    Mapping:
      The curve is re-parameterized uniformly by arc-length so one full
      revolution of the cam sweeps through the whole trajectory once.
      - curve X  →  axial Z position (centred, scaled to 85% of cam height)
      - curve Y  →  radial depth     (scaled to groove depth range)
      - angle    →  uniform 0→2π over arc length parameter
    """
    n = N_ANGULAR
    resampled = resample_by_arclength(curve, n)

    theta = np.linspace(0, 2 * np.pi, n, endpoint=False)

    # Axial: map X range → [margin, cam_height - margin]
    margin = cam_height * 0.075
    x_vals = resampled[:, 0]
    x_min, x_max = x_vals.min(), x_vals.max()
    if abs(x_max - x_min) < 1e-9:
        z_pos = np.full(n, cam_height / 2.0)
    else:
        z_pos = margin + (x_vals - x_min) / (x_max - x_min) * (cam_height - 2 * margin)

    # Radial: map Y range → [cam_radius - groove_depth, cam_radius]
    y_vals = resampled[:, 1]
    y_min, y_max = y_vals.min(), y_vals.max()
    if abs(y_max - y_min) < 1e-9:
        # Pure axial cam — constant radius
        r_pos = np.full(n, cam_radius - groove_depth * 0.5)
    else:
        # Map to inner half of groove depth for radial variation
        r_pos = (cam_radius - groove_depth * 0.9) + \
                (y_vals - y_min) / (y_max - y_min) * (groove_depth * 0.5)

    return theta, z_pos, r_pos


# ─────────────────────────────────────────────
#  GEOMETRY BUILDING
# ─────────────────────────────────────────────

def build_groove_centerline(theta, z_pos, r_pos):
    """
    Convert (theta, z, r) arrays to 3D Cartesian centerline of the groove.
    The centerline lies on the surface of the cam cylinder.
    """
    x = r_pos * np.cos(theta)
    y = r_pos * np.sin(theta)
    z = z_pos
    return np.column_stack([x, y, z])


def groove_tube_verts(centerline, theta, groove_width, groove_depth, n_prof):
    """
    Build a swept tube mesh along the groove centerline.
    The tube's cross-section is a rounded U-shape (semicircle bottom).

    Returns: vertices array (N_ANGULAR * n_prof, 3)
    """
    n = len(centerline)
    verts = np.zeros((n * n_prof, 3))

    # Frenet-Serret-ish frame for each centerline point
    for i in range(n):
        c = centerline[i]
        # Tangent: forward difference (wrap-around for closed curve)
        t_vec = centerline[(i + 1) % n] - centerline[(i - 1) % n]
        t_len = np.linalg.norm(t_vec)
        if t_len < 1e-12:
            t_vec = np.array([0.0, 0.0, 1.0])
        else:
            t_vec /= t_len

        # Radial outward direction at this angle
        angle = theta[i]
        radial = np.array([np.cos(angle), np.sin(angle), 0.0])

        # Normal into the cylinder surface (for groove cross-section)
        # Up = radial outward; side = tangential along surface
        up = -radial  # pointing inward (into the cam)
        side = np.cross(t_vec, up)
        side_len = np.linalg.norm(side)
        if side_len < 1e-12:
            side = np.array([-np.sin(angle), np.cos(angle), 0.0])
        else:
            side /= side_len

        # Cross-section: semicircular groove profile
        # phi goes from -π/2 to π/2 sweeping the bottom of the groove
        for j in range(n_prof):
            phi = np.pi * j / (n_prof - 1) - np.pi / 2
            # half-width at this phi
            w = (groove_width / 2.0) * np.cos(phi)
            # depth at this phi
            d = groove_depth * (1.0 - np.sin(phi)) / 2.0
            verts[i * n_prof + j] = c + w * side + d * up

    return verts


def triangulate_tube(n_angular, n_prof):
    """
    Build triangle indices for the groove tube surface (closed around the cam).
    Returns list of (i0, i1, i2) index triples.
    """
    tris = []
    n = n_angular
    p = n_prof

    for i in range(n):
        i_next = (i + 1) % n
        for j in range(p - 1):
            # quad between [i,j], [i_next,j], [i,j+1], [i_next,j+1]
            a = i      * p + j
            b = i_next * p + j
            c = i_next * p + j + 1
            d = i      * p + j + 1
            tris.append((a, b, c))
            tris.append((a, c, d))

    return tris


def build_cylinder(radius, height, n_angular, n_cap=1):
    """
    Build a solid closed cylinder: outer wall + top cap + bottom cap.
    Returns (vertices, triangles).
    """
    verts = []
    tris  = []

    # Bottom ring
    for i in range(n_angular):
        a = 2 * np.pi * i / n_angular
        verts.append([radius * np.cos(a), radius * np.sin(a), 0.0])
    # Top ring
    for i in range(n_angular):
        a = 2 * np.pi * i / n_angular
        verts.append([radius * np.cos(a), radius * np.sin(a), height])

    # Bottom center
    bc = len(verts); verts.append([0.0, 0.0, 0.0])
    # Top center
    tc = len(verts); verts.append([0.0, 0.0, height])

    # Side wall quads
    for i in range(n_angular):
        i2 = (i + 1) % n_angular
        b0 = i;              b1 = i2
        t0 = i + n_angular;  t1 = i2 + n_angular
        tris.append((b0, t0, t1))
        tris.append((b0, t1, b1))

    # Bottom cap (winding inward = normal downward)
    for i in range(n_angular):
        i2 = (i + 1) % n_angular
        tris.append((bc, i2, i))

    # Top cap (winding outward = normal upward)
    for i in range(n_angular):
        i2 = (i + 1) % n_angular
        tris.append((tc, i + n_angular, i2 + n_angular))

    return np.array(verts, dtype=float), tris


def compute_normal(v0, v1, v2):
    """Compute triangle face normal."""
    e1 = v1 - v0
    e2 = v2 - v0
    n = np.cross(e1, e2)
    length = np.linalg.norm(n)
    if length < 1e-15:
        return np.array([0.0, 0.0, 1.0])
    return n / length


# ─────────────────────────────────────────────
#  STL WRITER
# ─────────────────────────────────────────────

def write_stl_binary(filepath, all_triangles):
    """
    Write a binary STL file.
    all_triangles: list of (v0, v1, v2) where each v is a 3-element array.
    """
    n_tris = len(all_triangles)
    with open(filepath, 'wb') as f:
        # 80-byte header
        header = b'3D Cam Generator - github.com/chengcno/3DCamFollower inspired'
        f.write(header.ljust(80, b'\x00'))
        # Triangle count
        f.write(struct.pack('<I', n_tris))
        # Each triangle: normal(3f) + v0(3f) + v1(3f) + v2(3f) + attr(H)
        for v0, v1, v2 in all_triangles:
            n = compute_normal(np.array(v0), np.array(v1), np.array(v2))
            data = struct.pack('<3f', *n) + \
                   struct.pack('<3f', *v0) + \
                   struct.pack('<3f', *v1) + \
                   struct.pack('<3f', *v2) + \
                   struct.pack('<H', 0)
            f.write(data)
    print(f"  Wrote {n_tris:,} triangles → {filepath}")


# ─────────────────────────────────────────────
#  MAIN ASSEMBLY
# ─────────────────────────────────────────────

def generate_cam(curve, output_path,
                 radius=CAM_RADIUS,
                 height=CAM_HEIGHT,
                 groove_width=GROOVE_WIDTH,
                 groove_depth=GROOVE_DEPTH,
                 n_angular=N_ANGULAR,
                 n_profile=N_PROFILE):
    """
    Full pipeline: curve → cylindrical cam STL.
    """
    print(f"\n{'='*55}")
    print(f"  3D Cam Generator")
    print(f"{'='*55}")
    print(f"  Cam radius     : {radius} mm")
    print(f"  Cam height     : {height} mm")
    print(f"  Groove width   : {groove_width} mm")
    print(f"  Groove depth   : {groove_depth} mm")
    print(f"  Angular steps  : {n_angular}")
    print(f"  Input points   : {len(curve)}")
    print()

    # 1. Map trajectory to cam surface parameters
    print("  [1/4] Mapping trajectory to cam surface...")
    theta, z_pos, r_pos = normalize_to_cam(curve, radius, height, groove_depth)

    # 2. Build groove centerline on cylinder surface
    print("  [2/4] Building groove centerline...")
    centerline = build_groove_centerline(theta, z_pos, r_pos)

    # 3. Build cylinder body
    print("  [3/4] Building cylinder geometry...")
    cyl_verts, cyl_tris_idx = build_cylinder(radius, height, n_angular)

    # Convert cylinder to triangle soup
    cyl_triangles = []
    for tri in cyl_tris_idx:
        v0 = cyl_verts[tri[0]]
        v1 = cyl_verts[tri[1]]
        v2 = cyl_verts[tri[2]]
        cyl_triangles.append((v0, v1, v2))

    # 4. Build groove tube (the swept channel)
    print("  [4/4] Sweeping groove along trajectory...")
    tube_verts = groove_tube_verts(centerline, theta,
                                   groove_width, groove_depth, n_profile)
    tube_tris_idx = triangulate_tube(n_angular, n_profile)

    groove_triangles = []
    for tri in tube_tris_idx:
        v0 = tube_verts[tri[0]]
        v1 = tube_verts[tri[1]]
        v2 = tube_verts[tri[2]]
        # Flip winding so normals point into the groove (outward from surface)
        groove_triangles.append((v0, v2, v1))

    # 5. Add groove end-caps at seam (close the tube at angle = 0)
    # The groove is already closed because it wraps 360° around the cam.
    # We add shaft hole: a through-hole cylinder (6mm radius) for the axle
    shaft_r = 3.5  # mm — standard 7mm diameter shaft
    shaft_verts, shaft_tris_idx = build_cylinder(shaft_r, height, n_angular // 2)
    shaft_triangles = []
    for tri in shaft_tris_idx:
        v0 = shaft_verts[tri[0]]
        v1 = shaft_verts[tri[1]]
        v2 = shaft_verts[tri[2]]
        # Flip winding (shaft hole is subtracted, normals point inward)
        shaft_triangles.append((v0, v2, v1))

    # 6. Write STL
    all_tris = cyl_triangles + groove_triangles + shaft_triangles
    print(f"\n  Cylinder faces : {len(cyl_triangles):>6,}")
    print(f"  Groove faces   : {len(groove_triangles):>6,}")
    print(f"  Shaft faces    : {len(shaft_triangles):>6,}")
    print(f"  Total faces    : {len(all_tris):>6,}")
    print()

    write_stl_binary(output_path, all_tris)

    # Print some stats about the groove path
    z_range = z_pos.max() - z_pos.min()
    r_range = r_pos.max() - r_pos.min()
    print(f"\n  Groove stats:")
    print(f"    Axial travel   : {z_range:.1f} mm  "
          f"(Z: {z_pos.min():.1f} → {z_pos.max():.1f})")
    print(f"    Radial travel  : {r_range:.1f} mm  "
          f"(R: {r_pos.min():.1f} → {r_pos.max():.1f})")
    print(f"\n  Done! Open '{output_path}' in your slicer or CAD tool.")
    print(f"{'='*55}\n")

    return theta, z_pos, r_pos


# ─────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────

DEMO_CURVES = {
    "figure8":    demo_figure8,
    "sine":       demo_sine_wave,
    "helix_lobe": demo_helix_lobe,
    "star":       demo_star,
}

if __name__ == "__main__":
    args = sys.argv[1:]

    # Parse arguments
    curve_source = None
    output_file  = None
    demo_name    = "figure8"

    for arg in args:
        if arg.endswith('.csv') or arg.endswith('.txt'):
            curve_source = arg
        elif arg.endswith('.stl'):
            output_file = arg
        elif arg in DEMO_CURVES:
            demo_name = arg

    # Load or generate curve
    if curve_source:
        if not os.path.exists(curve_source):
            print(f"ERROR: Input file '{curve_source}' not found.")
            sys.exit(1)
        print(f"Loading curve from: {curve_source}")
        curve = load_curve_csv(curve_source)
    else:
        print(f"No input file given — using built-in demo: '{demo_name}'")
        print(f"Available demos: {', '.join(DEMO_CURVES.keys())}")
        print(f"Usage: python cam_generator.py [curve.csv] [output.stl] [demo_name]")
        curve = DEMO_CURVES[demo_name]()

    # Set output filename
    if not output_file:
        base = os.path.splitext(curve_source)[0] if curve_source else demo_name
        output_file = f"cam_{base}.stl"

    # Run the generator
    generate_cam(curve, output_file)
